"""
Import the app from run.py to make gunicorn work with the workflow
"""
from run import app